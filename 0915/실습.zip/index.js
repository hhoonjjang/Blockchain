let coinAmount = 1000;
let count = 0;
document.getElementById("powerButton").onclick = () => {
  if (count % 2 == 0) {
    calc();
    change();
  } else {
    reset();
  }
  count++;
};

function insert() {
  coinAmount += 1000;
}

document.getElementById("insert").onclick = () => {
  insert();

  calc();
};

function calc() {
  document.getElementById("coinAmount").innerText = coinAmount;
}
let isReset = false;

function reset() {
  isReset = true;
  document.getElementById("coinAmount").innerText = "";
  coinAmount = 1000;
  document.getElementById("change").innerHTML = "";
}
let changeIndex = -1;
let obTimeout;

function changeIndexReset() {
  changeIndex = 0;
}

document.getElementById("userScissor").onclick = () => {
  imgStop();
  document.getElementById("userRock").classList.add("displayoff");
  document.getElementById("userPaper").classList.add("displayoff");
  if (changeIndex == 0) {
    document.getElementById("draw").classList.add("displayOpacity");
    setTimeout(function () {
      console.log("비겼습니다.");
      calc();
      document.getElementById("draw").classList.remove("displayOpacity");
      document.getElementById("userRock").classList.remove("displayoff");
      document.getElementById("userPaper").classList.remove("displayoff");
      change();
    }, 2000);
  } else if (changeIndex == 1) {
    document.getElementById("lose").classList.add("displayOpacity");
    coinAmount -= 1000;

    setTimeout(function () {
      console.log("졌다");
      calc();
      document.getElementById("lose").classList.remove("displayOpacity");
      document.getElementById("userRock").classList.remove("displayoff");
      document.getElementById("userPaper").classList.remove("displayoff");
      change();
    }, 2000);
  } else {
    document.getElementById("win").classList.add("displayOpacity");
    document.getElementById("win1").classList.add("displayOpacity");
    coinAmount += 1000;

    setTimeout(function () {
      console.log("이겼다");
      calc();
      document.getElementById("win").classList.remove("displayOpacity");
      document.getElementById("win1").classList.remove("displayOpacity");
      document.getElementById("userRock").classList.remove("displayoff");
      document.getElementById("userPaper").classList.remove("displayoff");
      change();
    }, 2000);
  }
};

document.getElementById("userRock").onclick = () => {
  imgStop();
  document.getElementById("userScissor").classList.add("displayoff");
  document.getElementById("userPaper").classList.add("displayoff");
  if (changeIndex == 1) {
    document.getElementById("draw").classList.add("displayOpacity");
    setTimeout(function () {
      console.log("비겼습니다.");
      calc();
      document.getElementById("draw").classList.remove("displayOpacity");
      document.getElementById("userRock").classList.remove("displayoff");
      document.getElementById("userPaper").classList.remove("displayoff");
      change();
    }, 2000);
  } else if (changeIndex == 2) {
    document.getElementById("lose").classList.add("displayOpacity");
    coinAmount -= 1000;

    setTimeout(function () {
      console.log("졌다");
      calc();
      document.getElementById("lose").classList.remove("displayOpacity");
      document.getElementById("userRock").classList.remove("displayoff");
      document.getElementById("userPaper").classList.remove("displayoff");
      change();
    }, 2000);
  } else {
    document.getElementById("win").classList.add("displayOpacity");
    document.getElementById("win1").classList.add("displayOpacity");
    coinAmount += 1000;

    setTimeout(function () {
      console.log("이겼다");
      calc();
      document.getElementById("win").classList.remove("displayOpacity");
      document.getElementById("win1").classList.remove("displayOpacity");
      document.getElementById("userRock").classList.remove("displayoff");
      document.getElementById("userPaper").classList.remove("displayoff");
      change();
    }, 2000);
  }
};

document.getElementById("userRock").onclick = () => {
  console.log("Rock");
  imgStop();
};
document.getElementById("userPaper").onclick = () => {
  console.log("paper");
  imgStop();
};

let isStop = false;
function imgStop() {
  console.log("stop");
  isStop = true;
}

function change() {
  {
    if (isReset) {
      isReset = false;
      console.log(isReset);
      return;
    }
    if (isStop) {
      if (document.getElementById) isStop = false;
      return;
    }
    changeIndex++;
    if (changeIndex == 3) {
      changeIndex = 0;
    }
    if (changeIndex < 3) {
      document.getElementById("change").innerHTML = `<img src="${
        changeIndex % 3
      }.PNG" alt="" id = "changeImg1"/>`;
      obTimeout = setTimeout("change()", 1000);
    }
    //  else if (changeIndex >= 3) {
    //   debugger;
    //   changeIndex = 0;
    // }
    // } else {
    //   clearTimeout(obTimeout);
    // }
  }
  console.log(changeIndex);
}

// setInterval(change(), 2000);

// function startAnimation() {
//   obTimeout = window.setTimeout(change, 100);
// }
// window.onload = startAnimation;
// let changeArray = [];
// changeArray[0] = "0.png";
// changeArray[1] = "1.png";
// changeArray[2] = "2.png";
// console.log(changeArray);
// let nObjectCnt = 0;
